const PLUS = document.querySelector(".addButton");
const MINUS = document.querySelector(".minusButton");
const TIMES = document.querySelector(".timesButton");
const DIVIDE = document.querySelector(".divideButton");
const REMAINDER = document.querySelector(".remainderButton");
const CLEAR = document.querySelector(".clearButton");
const CLOSE = document.querySelector(".closeButton");
const RESULT = document.querySelector(".result");
const INPUTA = document.querySelector(".firstNumber");
const INPUTB = document.querySelector(".secondNumber");
const TEXTA = document.querySelector(".textA");
const TEXTB = document.querySelector(".textB");
const BOXA = document.querySelector(".boxA");
const BOXB = document.querySelector(".boxB");

function plusClicked() {
	//Checks the values entered when the button is pressed and passes them on if they are valid
	var first = document.querySelector(".firstNumber").value;
	var second = document.querySelector(".secondNumber").value;
	if (first != "" && second != "") {
		first = Number(first);
		second = Number(second);
	
		doMaths(first, second, 1);
		
	} else {
		RESULT.innerHTML = "One of the values you entered is not a number";
	}
}

function minusClicked() {
	//Checks the values entered when the button is pressed and passes them on if they are valid
	var first = document.querySelector(".firstNumber").value;
	var second = document.querySelector(".secondNumber").value;
	if (first != "" && second != "") {
		first = Number(first);
		second = Number(second);
	
		doMaths(first, second, 2);
		
	} else {
		RESULT.innerHTML = "One of the values you entered is not a number";
	}
}

function timesClicked() {
	//Checks the values entered when the button is pressed and passes them on if they are valid
	var first = document.querySelector(".firstNumber").value;
	var second = document.querySelector(".secondNumber").value;
	if (first != "" && second != "") {
		first = Number(first);
		second = Number(second);
	
		doMaths(first, second, 3);
		
	} else {
		RESULT.innerHTML = "One of the values you entered is not a number";
	}
}

function divideClicked() {
	//Checks the values entered when the button is pressed and passes them on if they are valid
	var first = document.querySelector(".firstNumber").value;
	var second = document.querySelector(".secondNumber").value;
	if (first != "" && second != "") {
		first = Number(first);
		second = Number(second);
	
		doMaths(first, second, 4);
		
	} else {
		RESULT.innerHTML = "One of the values you entered is not a number";
	}
}

function remainderClicked() {
	//Checks the values entered when the button is pressed and passes them on if they are valid
	var first = document.querySelector(".firstNumber").value;
	var second = document.querySelector(".secondNumber").value;
	if (first != "" && second != "") {
		first = Number(first);
		second = Number(second);
	
		doMaths(first, second, 5);
		
	} else {
		RESULT.innerHTML = "One of the values you entered is not a number";
	}
}



function doMaths(a, b, operation) {
	//Does the relevent maths operation
	if (operation == 1){
		
		RESULT.innerHTML = a + b;
		
	} else if (operation == 2){
		
		RESULT.innerHTML = a - b;
		
	} else if (operation == 3){
		
		RESULT.innerHTML = a * b;
		
	} else if (operation == 4){
		
		RESULT.innerHTML = a / b;
		
	} else {
		
		RESULT.innerHTML = a % b;
	}
	
}

function clearClicked() {
	//Clears the fields
	RESULT.innerHTML = "";
	INPUTA.value = "";
	INPUTB.value = "";
	
}

function closeClicked() {
	
	//Removes the page content
	RESULT.innerHTML = "Thank you for using the calculator app";
	PLUS.innerHTML = "";
	MINUS.innerHTML = "";
	TIMES.innerHTML = "";
	DIVIDE.innerHTML = "";
	REMAINDER.innerHTML = "";
	CLEAR.innerHTML = "";
	CLOSE.innerHTML = "";
	TEXTA.innerHTML = "";
	TEXTB.innerHTML = "";
	BOXA.innerHTML = "";
	BOXB.innerHTML = "";
	PLUS.removeEventListener('mouseenter', plusChangeColorOnTouch, false);
	MINUS.removeEventListener('mouseenter', minusChangeColorOnTouch, false);
	TIMES.removeEventListener('mouseenter', timesChangeColorOnTouch, false);
	DIVIDE.removeEventListener('mouseenter', divideChangeColorOnTouch, false);
	REMAINDER.removeEventListener('mouseenter', remainderChangeColorOnTouch, false);
	CLEAR.removeEventListener('mouseenter', clearChangeColorOnTouch, false);
	CLOSE.removeEventListener('mouseenter', closeChangeColorOnTouch, false);
	
}


//Code to change the colour of the elements on hover	
function plusChangeColorOnTouch() {
    PLUS.style.backgroundColor = "green";
    PLUS.style.borderColor = "green";
}
function minusChangeColorOnTouch() {
    MINUS.style.backgroundColor = "green";
    MINUS.style.borderColor = "green";
}
function timesChangeColorOnTouch() {
    TIMES.style.backgroundColor = "green";
    TIMES.style.borderColor = "green";
}
function divideChangeColorOnTouch() {
    DIVIDE.style.backgroundColor = "green";
    DIVIDE.style.borderColor = "green";
}
function remainderChangeColorOnTouch() {
    REMAINDER.style.backgroundColor = "green";
    REMAINDER.style.borderColor = "green";
}
function clearChangeColorOnTouch() {
    CLEAR.style.backgroundColor = "green";
    CLEAR.style.borderColor = "green";
}
function closeChangeColorOnTouch() {
    CLOSE.style.backgroundColor = "green";
    CLOSE.style.borderColor = "green";
}


PLUS.addEventListener('mouseenter', plusChangeColorOnTouch, false);
PLUS.addEventListener('mouseleave', function(){PLUS.removeAttribute("style");}, false);

MINUS.addEventListener('mouseenter', minusChangeColorOnTouch, false);
MINUS.addEventListener('mouseleave', function(){MINUS.removeAttribute("style");}, false);

TIMES.addEventListener('mouseenter', timesChangeColorOnTouch, false);
TIMES.addEventListener('mouseleave', function(){TIMES.removeAttribute("style");}, false);

DIVIDE.addEventListener('mouseenter', divideChangeColorOnTouch, false);
DIVIDE.addEventListener('mouseleave', function(){DIVIDE.removeAttribute("style");}, false);

REMAINDER.addEventListener('mouseenter', remainderChangeColorOnTouch, false);
REMAINDER.addEventListener('mouseleave', function(){REMAINDER.removeAttribute("style");}, false);

CLEAR.addEventListener('mouseenter', clearChangeColorOnTouch, false);
CLEAR.addEventListener('mouseleave', function(){CLEAR.removeAttribute("style");}, false);

CLOSE.addEventListener('mouseenter', closeChangeColorOnTouch, false);
CLOSE.addEventListener('mouseleave', function(){CLOSE.removeAttribute("style");}, false);


PLUS.onclick = plusClicked;
MINUS.onclick = minusClicked;
TIMES.onclick = timesClicked;
DIVIDE.onclick = divideClicked;
REMAINDER.onclick = remainderClicked;
CLEAR.onclick = clearClicked;
CLOSE.onclick = closeClicked;

